from distutils.core import setup

setup(
    name='ftPwrDrive.py',
    version='1.0',
    packages=['ftpwrdrive'],
    url='',
    license='GPL',
    author='Bloeckchengrafik',
    author_email='ftpi@gmx.de',
    description='The FtPwrDrive Python Lib'
)
